<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  
    <style>
      img{
        width: 250px;
        height: 200px;
        clear: both;
      }
    </style>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link rel="stylesheet" href="./style2.css" />
    <title>Sidebar</title>

  </head>
  <body>
  
 <?php 
include 'admin.php';
?>
   
   <div class="sidebar">
      <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Administrator</p>
  <a href="OracleAdminHome.php">Home</a>
  <a href="OracleAdminResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleAdminOperations.php">Operations</a>
  <a href="OracleAdminUserManagement.html">User Management
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>


<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div> 

    <div class="content">
      <div class="card">
        <a href="./addUser.php">
          <div class="container">
            <h4>ADD USER</h4>
  
          </div>
        </a>

        <a href="./updateUser.php">
          <div class="container">
            <h4>UPDATE USER</h4>
        
          </div>
        </a>
      </div>


      <div class="card">
          <a href="./removeUser.php">  
            <div class="container">
              <h4><b>REMOVE USER</b></h4>
               
            </div>
          </a>  

          <a href="./searchUser.php">
              <div class="container">
                <h4><b>SEARCH USER</b></h4>    
              </div>
          </a>
    </div>
	
<br><br><br><br><br><br><br><br><br><br><br><br>			
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
