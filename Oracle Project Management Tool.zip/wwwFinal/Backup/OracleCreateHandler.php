<?php 
session_start();
?>
<html>
<head>
<title>Insert Result</title>
</head>
<style>

body {background-color:#3D0105;}

</style>

<body>

<?php 


$un = $_POST['un'];
$pw = $_POST['pw'];
$ue = $_POST['uEmail'];

$role = "user";

$qstatement = " insert into users (uName, uPassword, uEmail, uRole) values ('$un', '$pw', '$ue', '$role'); ";


$connect = mysqli_connect("127.0.0.1","Oracle","123","Oracle");

//User name will be Oracle, Password 123. Database name Oracle


$display = mysqli_query($connect, $qstatement);
print $display;

mysqli_close($connect);

//Create a message that says account has been created
header('Location:./OracleLogin.html');

?>



</body>
</html>