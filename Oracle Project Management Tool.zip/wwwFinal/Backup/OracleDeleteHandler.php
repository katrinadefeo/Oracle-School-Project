<?php 

session_start();
$del = $_POST['del'];
$pName = $_POST['pName'];
$pOwn = $_POST['pOwn'];

$check = " SELECT * from project where pName ='$pName' AND uName = '$pOwn';";
$checkMul = " SELECT * from project where uName = '$pOwn';";
$qstatement = "DELETE FROM project WHERE pName = '$pName' AND uName = '$pOwn';";
$qStateMult = "DELETE FROM project WHERE uName = '$pOwn';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$value = mysqli_query($connect, $check);
$values = mysqli_query($connect, $checkMul);


if($del == 'Delete Multiple')
{
	echo $qStateMult;
	mysqli_query($connect, $qStateMult);
	mysqli_close($connect);
	header('Location:./OracleAdminRemoveProject.php');

}

else
{
	mysqli_query($connect, $qstatement);
	mysqli_close($connect);
	header('Location:./OracleAdminRemoveProject.php');
}


?>