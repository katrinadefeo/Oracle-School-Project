<?php 

session_start();
$del = $_POST['del'];
$tName = $_POST['tName'];
$tOwn = $_POST['tOwn'];

$check = " SELECT * from tasks where tName ='$tName' AND uName = '$tOwn';";
$checkMul = " SELECT * from tasks where uName = '$tName';";
$qstatement = "DELETE FROM tasks WHERE tName = '$tName' AND uName = '$tOwn';";
$qStateMult = "DELETE FROM oracle.tasks WHERE uName = '$tOwn';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$value = mysqli_query($connect, $check);
$values = mysqli_query($connect, $checkMul);


if($del == 'Delete Multiple')
{
	mysqli_query($connect, $qStateMult);
	mysqli_close($connect);
	header('Location:OracleAdminRemoveTask.php');

}

else 
{
	mysqli_query($connect, $qstatement);
	mysqli_close($connect);
	echo "$qstatement";
	header('Location:./OracleAdminRemoveTask.php');
}


?>