<html>
<title>Log Out </title>
<body>

<?php
Session_start();
Session_unset();
Session_destroy();
Header('Location:./OracleLogin.html');

?>

</body>
</html>