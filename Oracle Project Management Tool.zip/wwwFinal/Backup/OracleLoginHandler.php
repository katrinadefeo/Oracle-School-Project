<?php
session_start();
?>

<html>

<style>

body {background-color:#3D0105;}
</style>

<body>

<?php



$un = $_POST['un'];
$pw = $_POST['pw'];


$query =" SELECT * FROM Users WHERE uName = '$un' AND uPassword ='$pw' ;" ;


$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

//User name will be Oracle, Password 123. Database name Oracle

if(mysqli_connect_errno())
{
	echo "Failed to connect" . mysqli_connect_error();
}

$result = mysqli_query($connect, $query);

$row = mysqli_fetch_array($result);

if($row == null)
{
	Session_unset();
	Session_destroy();
	Header('Location:./loginfail.html');
	exit;
}

else{
	
	$_SESSION["role"]= "$row[6]";
	$_SESSION["un"]="$un";
	Header('Location:./OracleHome.php');
	exit;
	
}

 mysqli_close($connect); 


?>

</body>
</html>