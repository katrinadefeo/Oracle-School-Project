<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
 
 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Operations</title>
  </head>
  
  <style>
  a:link {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: blue;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: white;
  background-color: transparent;
  text-decoration: underline;
}
  </style>
  <body>
   
 <?php
//This is to check if the user is a manager
if($_SESSION["role"]!="manager")
header('Location:./InvalidCredentials.php');

?>


   
   <div class="sidebar">
      <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
  <a href="NewOracleManagerHome.php">Home</a>
  <a href="OracleManagerResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleManagerOperations.php">Operations</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>

<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>

    <div class="content">
      <div class="card">
        <!--Container for Adding Projects-->
        <div class="container">
          <h4><b>Projects</b></h4>
          <p>
            <br><br>
			<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Click <a href="OracleManagerProjects.php">Here</a> to view Projects
          </p>
        </div>
		<!--Container for Adding Tasks-->
		<div class="container">
          <h4><b>Tasks</b></h4>
          <p>
            <br><br>
			<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Click<a href="OracleManagerTasks.php"> Here</a> to view Tasks
		  </p>
        </div>
		<!--Container for Remove Project-->
		 <div class="container">
          <h4><b>Remove Project</b></h4>
          <p>
            <br><br>
			<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Click <a href="OracleManagerRemoveProject.php">Here</a> to Remove Projects
          </p>
        </div>
		 
		 <!--Container for Remove Tasks-->
		 <div class="container">
          <h4><b>Remove Tasks</b></h4>
          <p>
            <br><br>
			<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Click <a href="OracleManagerRemoveTask.php">Here</a> to Remove Projects
          </p>
        </div>
      </div>
      
      </div>
      
  
	
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
