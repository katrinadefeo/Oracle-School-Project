<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>

 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Projects</title>
	
 <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}


 </style>
  
  <script>
            
           
          
   function addRow()
            {
                // get input values
                var pName = document.getElementById('pName').value;
                var pDue = document.getElementById('pDue').value;
                var pPriority = document.getElementById('pPriority').value;
				var pContactFName = document.getElementById('pContactFName').value;
                var pContactLName = document.getElementById('pContactLName').value;
                  // get the html table
                  // 0 = the first tble
                  var table = document.getElementsByTagName('table')[0];
                  
                  // add new empty row to the table
                  // 0 = in the top 
                  // table.rows.length = the end
                  // table.rows.length/2+1 = the center
                  var newRow = table.insertRow(table.rows.length/4+1);
                  
                  // add cells to the row
                  var cel1 = newRow.insertCell(0);
                  var cel2 = newRow.insertCell(1);
                  var cel3 = newRow.insertCell(2);
				  var cel4 = newRow.insertCell(3);
				  var cel5 = newRow.insertCell(4);
                  
                  // add values to the cells
                  cel1.innerHTML = pName;
                  cel2.innerHTML = pDue;
                  cel3.innerHTML = pPriority;
				  cel4.innerHTML = pContactFName;
				  cel5.innerHTML = pContactLName;
            }

		  
            
        </script>
  
  </head>
  <body>
   
<?php
//This is to check if the user is a manager
if($_SESSION["role"]!="manager")
header('Location:./InvalidCredentials.php');

?>

   
   <div class="sidebar">
      <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
  <a href="NewOracleManagerHome.php">Home</a>
  <a href="OracleManagerResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleManagerOperations.php">Operations</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>

<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>

<p style ="text-align:center"> 
 Project Name: <input type="text" name="pName" id="pName" />
 Project Due: <input type="text" name="pDue" id="pDue" />
  <label for="pPriority">Priority:</label>
    <select id="pPriority" name="pPriority">
      <option style ="background-color : red;" value="High">High</option>
      <option value="Medium">Medium</option>
      <option value="Low">Low</option>
    </select>
<br/><br/>
 Contact First Name: <input type="text" name="pContactFName" id="pContactFName" />&nbsp;&nbsp;
 Contact Last Name: <input type="text" name="pContactLName" id="pContactLName" /><br><br>
 
     <button onclick="addRow();">Add Row</button><br/><br/>
</p>		
		

<!--Example for Drop down for Priority-->
 <label for="country">Country</label>
    <select id="country" name="country">
      <option value="australia">Australia</option>
      <option value="canada">Canada</option>
      <option value="usa">USA</option>
    </select>

<table style="width:700px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Project Name</th>
                <th>Project Due</th>
                <th>Priority</th>
				<th>Contact First Name</th>
				<th>Contact Last Name</th>
            </tr>
            
            <tr>
                <td>Project Management Tool Review</td>
                <td>December 01, 2020</td>
                <td>High</td>
				<td>Benard</td>
				<td>Cheserem</td>
				
            </tr>
            
             <tr>
                <td>Database Management</td>
                <td>December 01, 2020 </td>
                <td>Medium</td>
				<td>Mohammed</td>
				<td>Shaikh</td>
				
            </tr>
            
             <tr>
                <td>Team Management</td>
                <td>December 01, 2020</td>
                <td>Low</td>
				<td>Nicholas</td>
				<td>Traczek</td>
				
            </tr>
            
          
            
        </table>
	
<br><br><br><br><br><br><br><br><br><br><br><br>		
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>