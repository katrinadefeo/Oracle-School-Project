<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>


    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
	<link rel="stylesheet" href="./OracleForm.css" />
	
    <title>Oracle Admin Remove Task</title>
<style>	
input[type=text], select {
  width: 40%;
  padding: 12px 20px;
  text-align: center;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  clear: both;
}


.container2 input {
  width: 100%;
  clear: both;
}

input[type=submit] {
  width: 100%;
  background-color: #F00909;
  text-align: center;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #B90909;
}

div {
  
  border-radius: 5px;
  background-color: #white;
  padding: 20px;
}
</style>
<body>

<?php
//This is to check if the user is a manager
if($_SESSION["role"]!="manager")
header('Location:./InvalidCredentials.php');

?>


<!--Nav bar-->
<div class="sidebar">
     <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
  <a href="NewOracleManagerHome.php">Home</a>
  <a href="OracleManagerResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleManagerOperations.php">Operations</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div> 
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>



<div class="container2">
<!--Make a file to connect to database. For now we will use the made up and non-existant file /action.php: form action="/action_page.php">--> 
 <form align="center">
 <p style="center">
	<h3>
	Remove Task
	</h3>
    </p>
    <label for="tName">Task Name</label>
    <input type="text" id="tName" name="firstname" placeholder="Task Name">

   <!-- <label for="tID">PID</label>
    <input type="text" id="PID" name="lastname" placeholder="PID">-->
    <input type="submit" value="Delete">
  </form>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br>			


<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
</body>
</html>
