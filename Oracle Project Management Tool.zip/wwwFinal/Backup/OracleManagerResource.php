<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>

 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Resource</title>
	
 <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
 </style>
  
  <script>
            
            function addRow()
            {
                // get input values
                var Name = document.getElementById('Name').value;
                var PUtilization = document.getElementById('PUtilization').value;
                
				  
                  
                  // get the html table
                  // 0 = the first table
                  var table = document.getElementsByTagName('table')[0];
                  
                  // add new empty row to the table
                  // 0 = in the top 
                  // table.rows.length = the end
                  // table.rows.length/1+1 = the center
                  var newRow = table.insertRow(table.rows.length/6+1);
                  
                  // add cells to the row
                  var cel1 = newRow.insertCell(0);
                  var cel2 = newRow.insertCell(1);
                  
                  
                  // add values to the cells
                  cel1.innerHTML = Name;
                  cel2.innerHTML = PUtilization;
                  
				  
            }
            
        </script>
  
  </head>
  <body>
   
 <?php
//This is to check if the user is a manager
if($_SESSION["role"]!="manager")
header('Location:./InvalidCredentials.php');

?>
   
   <div class="sidebar">
      <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
  <a href="NewOracleManagerHome.php">Home</a>
  <a href="OracleManagerResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleManagerOperations.php">Operations</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>

<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>

<p style ="text-align:center"> 
 Name: <input type="text" name="Name" id="Name" /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
 Percent Utilization: <input type="text" name="PUtilization" id="PUtilization" />
 <button onclick="addRow();">Add Row</button><br/><br/>
 

</p>		
		


<table style="width:700px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Name</th>
                <th>Percent Utilization</th>
             
            </tr>
            
            <tr>
                <td>Benard Cheserem</td>
                <td>90 %</td>
                
            </tr>
            
             <tr>
                <td>Mohammed Shaikh</td>
                <td>90 %</td>
            </tr>
            
             <tr>
                <td>Nick Traczek</td>
                <td>90 %</td>
              
            </tr>
            
          
            
        </table>
	
<br><br><br><br><br><br><br><br><br><br><br><br>		
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>