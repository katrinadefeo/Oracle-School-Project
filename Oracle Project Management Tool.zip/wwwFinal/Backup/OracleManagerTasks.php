<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>

 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Operations</title>
	
 <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
 </style>
  <!--JavaScript-->
  <script>
            
            function addRow()
            {
                // get input values
                var tName = document.getElementById('tName').value;
                 var tDue = document.getElementById('tDue').value;
                  var tPriority = document.getElementById('tPriority').value;
				  var tDuration = document.getElementById('tDuration').value;
				  var tDependants = document.getElementById('tDependants').value;
			
                  
                  // get the html table
                  // 0 = the first table
                  var table = document.getElementsByTagName('table')[0];
                  
                  // add new empty row to the table
                  // 0 = in the top 
                  // table.rows.length = the end
                  // table.rows.length/6+1 = the center
                  var newRow = table.insertRow(table.rows.length/6+1);
                  
                  // add cells to the row
                  var cel1 = newRow.insertCell(0);
                  var cel2 = newRow.insertCell(1);
                  var cel3 = newRow.insertCell(2);
				  var cel5 = newRow.insertCell(3);
				  var cel6 = newRow.insertCell(4);
				  
                  
                  // add values to the cells
                  cel1.innerHTML = tName;
                  cel2.innerHTML = tDue;
                  cel3.innerHTML = tPriority;
				  cel4.innerHTML = tDuration;
				  cel5.innerHTML = tDependants;
				  
            }
            
        </script>
  
  </head>
  <body>
 <?php
//This is to check if the user is a manager
if($_SESSION["role"]!="manager")
header('Location:./InvalidCredentials.php');

?>
 
	
   
   <div class="sidebar">
      <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
  <a href="NewOracleManagerHome.php">Home</a>
  <a href="OracleManagerResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleManagerOperations.php">Operations</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>

<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>

<!--Table Input Fields with Add row button-->
<p style ="text-align:center"> 
 Task Name: <input type="text" name="tName" id="tName" />
 Task Due: <input type="text" name="tDue" id="tDue" />
   <label for="tPriority">Priority:</label>
   <select id="tPriority" name="tPriority">
      <option value="High">High</option>
      <option value="Medium">Medium</option>
      <option value="Low">Low</option>
    </select>
	<br><br>	

 Duration: <input type="text" name="tDuration" id="tDuration" />
 Dependants: <input type="text" name="tDependants" id="tDependants" /><br><br>
 
 <button onclick="addRow();">Add Row</button><br/><br/>
</p>		
		

<!--Table Hard coded table information from JavaScript-->
<table style="width:500px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Task Name</th>
                <th>Task Due</th>
                <th>Priority</th>
			
				<th>Duration</th>
				<th>Dependants</th>
				
				
            </tr>
            
            <tr>
                <td>Set up Server</td>
                <td>October 18, 2020</td>
				<td>High</td>
				
				<td>4 days</td>
				<td>5</td>
				
            </tr>
           
             <tr>
                <td>Color Code Priority</td>
                <td>December 01, 2020 </td>
                <td>Medium</td>
			
				<td>48 days</td>
				<td>5</td>
				
            </tr>
            
             <tr>
                <td>List Higher Priorities First</td>
                <td>December 01, 2020</td>
                <td>Low</td>
			
				<td>48 days</td>
				<td>2</td>
			
            </tr>
            
          
            
        </table>
	
<br><br><br><br><br><br><br><br><br><br><br><br>			
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>