<?php
session_start();
?>

<html>
<body>

<?php
//variables
$uName = $_POST['uName1'];
$uNameLogin = $_SESSION["uName"];
$uRole = $_SESSION["role"];
$pName = $_POST['pName'];
$tName = $_POST['tName'];
$cName = $_POST['cName'];
$value = $_POST['value'];
$wUpdate = $_POST['sub'];

//queries
$updateUser = "update users set '$cName'='$value' where uName='$uName';";
$updateProj = "update project set '$cName'=$value' where pName='$pName';";
$updateTask = "update task set '$cName'='$value' where tName='$tName';";

//connection
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//ifs
if($wUpdate == "user")
{
	if($uRole != "admin" AND $uName != $uNameLogin)
	{
			header('Location:./InvalidCredentials.php');
	}
	$qUser = mysqli_query($connect, $updateUser);
	mysqli_close($connect);
	header('Location:./InvalidCredentials.php');
	
}
else if
($wUpdate == "project")
{
	$qProject = mysqli_query($connect, $updateProj);
	mysqli_close($connect);
	
}
else if
($wUpdate == "task")
{
	$qTask = mysqli_query($connect, $updateTask);
	mysqli_close($connect);
}
else
{
	echo 'You have reached this page in error and have been signed out. Please login and try again.';
	Session_unset();
	Session_destroy();
	mysqli_close($connect);
	exit;
}


?>

</body>
</html>