<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
  </head>
  
  
  <body>
 <?php
//This is to check if the user is a user
if($_SESSION["role"]!="user")
header('Location:./InvalidCredentials.php');

include './OracleIncludeNavbar.php';
?>

   

<?php

$query = "select count(*) from tasks where uName = '$_SESSION[un]';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

while($row = mysqli_fetch_array($result)) 
			{
				$temp = $row['count(*)'];	
			}
echo'

    <div class="content">
      <div class="card">
        <div class="container">
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;<h1><b>'.$_SESSION["un"].'</b></h1> <a href="./myTasks.php"> you have '. $temp .' tasks. </a>
          </p>
        </div>
	</div>
	  
    </div>';
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
