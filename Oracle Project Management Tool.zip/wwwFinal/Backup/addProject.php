<?php
session_start();
?>

<html>
<body>

<?php
//variables
$pName = $_POST['pName'];
$pDue = $_POST['pDue'];
$pOwn = $_POST['pOwn'];
$pPriority = $_POST['pPriority'];
$pBudget = $_POST['pBudget'];

//connection

$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//queries
$query = " insert into project (pName, pDue, pOwn, pPriority, pBudget) values ('$pName', STR_TO_DATE('$pDue','%Y-%m-%d'), '$pOwn', '$pPriority', '$pBudget'); ";


$result = mysqli_query($connect, $query);

mysqli_close($connect);

//Create a message that says account has been created
header('Location:./OracleAdminProjects.php');

?>
