<?php
session_start();
?>

<html>
<body>

<?php
//variables
$uName = $_POST['uName'];
$uEmail = $_POST['uEmail'];
$uPass = $_POST['uPassword'];

//connection
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");
;
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//queries
$uUserCheck = "select * from users where uName='$uName' AND uEmail='$uEmail';";
$updateUser = "update users set uPassword='$uPass' where uName='$uName' AND uEmail='$uEmail';";
$result = mysqli_query($connect, $uUserCheck);

//while
while ($row = mysqli_fetch_array($result))
{
mysqli_query($connect,$updateUser);	
mysqli_close($connect);
Header('Location:./ForgotPasswordDone.php');
exit;
}
Header('Location:./ForgotPasswordNone.php');
mysqli_close($connect);





?>
</body>
</html>