CREATE DATABASE IF NOT EXISTS `Oracle` ;

USE `Oracle`;

SET FOREIGN_KEY_CHECKS= 0 ;

/*
####################################################################################
##                                   Table Creation                               ##
####################################################################################
*/

CREATE TABLE IF NOT EXISTS Users (
	/*UserID INT NOT NULL AUTO_INCREMENT,*/
	uName VARCHAR (255) NOT NULL,
	fName VARCHAR (255),
	lName VARCHAR (255),
	uEmail VARCHAR(255) NOT NULL,
	uState VARCHAR (2),
	uPhone VARCHAR(15),
	uRole VARCHAR (10),
	uPassword VARCHAR (255) NOT NULL,
	CONSTRAINT U_Name PRIMARY KEY (uName) /*CONSTRAINT U_ID PRIMARY KEY (UserID)*/
) ;

CREATE TABLE IF NOT EXISTS UserAssign (
	AssignID INT NOT NULL AUTO_INCREMENT,
   uName VARCHAR (255) NOT NULL,  /* deleted UserID VARCHAR (255)*/
	pName VARCHAR (255), /* replaced PID */
	CONSTRAINT UA_PK PRIMARY KEY (AssignID),
	CONSTRAINT UA_FKa FOREIGN KEY (uName) REFERENCES Users (uName), /*CONSTRAINT UA_FKa FOREIGN KEY (UserID) REFERENCES Users (UserID),*/
	CONSTRAINT UA_FKb FOREIGN KEY (pName) REFERENCES Project (pName) /*CONSTRAINT UA_FKb FOREIGN KEY (PID) REFERENCES Project (PID)*/
) ;



CREATE TABLE IF NOT EXISTS Project (
	/*PID INT NOT NULL AUTO_INCREMENT,*/
	pName VARCHAR (255) NOT NULL,
	pOwn VARCHAR (255) NOT NULL,
	pDue date,
	pPriority VARCHAR (50),
	pContactFName VARCHAR (255),
	pContactLName VARCHAR (255),
	pContactEmail VARCHAR (255),
	uName VARCHAR (255) NOT NULL,
	pBudget int,
	pContactPhone VARCHAR (15),
	CONSTRAINT P_PK PRIMARY KEY (pName), /*CONSTRAINT P_PK PRIMARY KEY (PID),*/
	CONSTRAINT P_FKa FOREIGN KEY (uName) REFERENCES Users (uName) /*CONSTRAINT P_FKa FOREIGN KEY (UserID) REFERENCES Users (UserID)*/
) ;

CREATE TABLE IF NOT EXISTS Tasks (
	TID int NOT NULL AUTO_INCREMENT,
	tName VARCHAR (255),
	tDue date,
	tPercentage INT (3),
	tPriority VARCHAR (50),
	uName VARCHAR (255) NOT NULL,
	tDuration INT,
	tDependents VARCHAR (255),
	pName VARCHAR (255), /* replaced PID */
	CONSTRAINT T_PK PRIMARY KEY (TID),
	CONSTRAINT T_FKa FOREIGN KEY (uName) REFERENCES Users (uName), /*CONSTRAINT T_FKb FOREIGN KEY (UserID) REFERENCES Users (UserID)*/
	CONSTRAINT T_FKb FOREIGN KEY (pName) REFERENCES Project (pName) /*CONSTRAINT T_FKb FOREIGN KEY (PID) REFERENCES Project (PID)*/
) ;

/*SET FOREIGN_KEY_CHECKS=1 ;*/

/*
####################################################################################
##                                   Inserts                                      ##
####################################################################################
*/

INSERT INTO Users

 (uName, fName, lName, uEmail, uState, uPhone, uRole, uPassword) 

VALUES 
	
	("admin", "admin", "admin", "admin@uccs.edu", "CO", "7198888888", "admin", "admin"),
	("manager", "manager", "manager", "manager@uccs.edu", "CO", "7198888888", "manager", "manager"),
	("user", "user", "user", "user@uccs.edu", "CO", "7198888888", "user", "user"),
	("earroyo", "edgar", "arroyo", "edgar.arroyo@oracle.com", "CO", "7198888888", "admin", "admin"),
	("ntraczek", "nicholas", "traczek", "ntraczek@uccs.edu", "CO", "7199999999", "user", "user"),
	("kdefeo", "katrina", "defeo", "kdefeo@uccs.edu", "CO", "7199999999", "user", "user"),
	("bcheserem", "benard", "cheserem", "bchesere@uccs.edu", "CO", "7199999999", "user", "user"),
	("mshaikh", "mohammed", "shaikh", "mshaikh@uccs.edu", "CO", "7199999999", "user", "user");
	
INSERT INTO UserAssign

 (uName, pName) /* deleted UserID*/

VALUES 

	("earroyo", "UCCS team project"),
	("ntraczek", "Managing the team"),
	("kdefeo", "Website Development"),
	("bcheserem", "Quality Checking"),
	("mshaikh", "Oracle Database");

INSERT INTO Project

 (pName, pOwn, pDue, pPriority, pContactFName, pContactLName, pContactEmail, uName, pBudget, pContactPhone) /* Deleted UserID*/

VALUES 

	("UCCS team project", "Bob", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "High", "nicholas", "traczek", "ntraczek@uccs.edu", "earroyo", "65", "7198888888"),
	("Managing the team", "Nick", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "High", "nicholas", "traczek", "ntraczek@uccs.edu", "ntraczek", "75", "7198888888"),
	("Website Development", "Katrina", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "High", "katrina", "defeo", "kdefeo@uccs.edu", "kdefeo", "85", "7198888888"),
	("Quality Checking", "Benard", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "High", "benard", "cheserem", "bchesere@uccs.edu", "bcheserem", "165", "7198888888"),
	("Oracle Database", "Mohammed", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "Medium", "mohammed", "shaikh", "mshaikh@uccs.edu", "mshaikh", "40", "7199999999");
	
INSERT INTO Tasks

 (tName, tDue, tPercentage, tPriority, uName, tDuration, tDependents, pName) /* Deleted UserID*/

VALUES 

	("Discuss Deliverables", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "20", "High", "earroyo", "16", "dependent1", "UCCS team project"),
	("Contact the team", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "40", "Low", "earroyo", "16", "dependent2", "UCCS team project"),
	("Assign Roles", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "25", "High", "ntraczek", "16", "dependent3", "Managing the team"),
	("Checking on the team", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "30", "Low", "ntraczek", "16", "dependent4", "Managing the team"),
	("Writing the code", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "60", "High", "kdefeo", "16", "dependent5", "Website Development"),
	("Design website", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "80", "Low", "kdefeo", "16", "dependent6", "Website Development"),
	("Checking quality", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "95", "High", "bcheserem", "16", "dependent7", "Quality Checking"),
	("Checking progress", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "100", "Low", "bcheserem", "16", "dependent8", "Quality Checking"),
	("Design Database", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "45", "High", "mshaikh", "16", "dependent9", "Oracle Database"),
	("Adding extra features", STR_TO_DATE('2020-12-19','%Y-%m-%d'), "50", "Low", "mshaikh", "16", "dependent10", "Oracle Database");
	
/*
####################################################################################
##                                   Queries                                      ##
####################################################################################
*/

	/* See tasks per user */
	SELECT *
	FROM Tasks
	;
	
	/* See all high priority tasks */
	SELECT * 
	FROM Tasks
	WHERE tPriority = "High" 
	;
	
	/* See tasks per project */
	SELECT  tasks.*, Project.pName  /* Project.PID*/
	FROM tasks 
	INNER JOIN Project 
	ON tasks.pName = Project.pName 
	WHERE tasks.pName = Project.pName 
	;
	
	/* I want to see all my tasks */
	SELECT * 
	FROM Tasks 
	WHERE uName = "kdefeo"
	;
	
	/* I want to see all my high priority tasks */ 
	SELECT * 
	FROM Tasks 
	WHERE uName = "kdefeo" AND tPriority = "High"
	;
