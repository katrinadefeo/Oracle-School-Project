<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

 <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Admin Projects</title>
</head>
<title>add_user</title>
<style>
	.userForm{
		background-color: #C74634;
		margin-right: 12%;
		margin-left: 12%;
		padding:5% 15% 5%;
		color: #fff;
		text-align: center;
		justify-content: center;
		border-radius: 15px;
	}
	label {
		padding-left: 0.5%;
		font-size: 1.5em;

	}

</style>
	
</head>

<body>

<?php 
include 'admin.php';
?>
   

   <div class="sidebar">
      <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Administrator</p>
  <a href="OracleAdminHome.php">Home</a>
  <a href="OracleAdminResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleAdminOperations.php">Operations</a>
  <a href="OracleAdminUserManagement.html">User Management
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>


<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>
	<div class="userForm">
	<form action="OracleAdminAddProject.php" method="post">

		 	<caption><h2>Add project</h2></caption><hr><br><br>&nbsp&nbsp
		 	<label for="name">PID:</label><input type="text" id="PID" name "">&nbsp&nbsp
			<label for="pName">Project Name:</label><input type="text" id="pName" name=""><br><br><br><br>&nbsp&nbsp&nbsp
			<label for="pDue">Due Date:</label><input type="text" id="pDue" name="">&nbsp
			<label for="pPriority">Project Priority:</label><input type="text" id="pPriority"name=""><br><br><br><br>&nbsp&nbsp
			<label for ="PcontactFName">First name:</label><input type="text" id="pContactFName"name="">&nbsp
			<label for ="PcontactLName">Last name:</label><input type="text" id="pContactLName"name=""><br><br><br><br>&nbsp&nbsp
			<label for ="pContactEmail">Contact Email:</label><input type="text" id="pContactEmail"name="">&nbsp&nbsp
			<label for ="UserID">User ID:</label><input type="text" id="UserID"name=""><br><br><br><br>&nbsp&nbsp
			<label for="pBudget">Project Budget:</label><input type="text" name="pBudget" name="">&nbsp&nbsp
			<label for="pContactPhone">Contact Phone:</label><input type="text" name="PID" name=""><br><br><br><br>&nbsp&nbsp
			<input type="submit" id="Sbutton" name ="Submit">
	
	</form>
	</div>
	
	<br><br><br><br><br><br><br><br><br><br><br><br>			
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>


</body>
</html>