<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
 </head>
  
  
  <body>
 <?php
//This is to check if the user is a user
if($_SESSION["role"]!="user")
header('Location:./InvalidCredentials.php');

?>

   
    <div class="sidebar">
   
	
	<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;User</p>
  <a href="OracleUserHome.php">Home</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Settings</a>
 <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>
</div>
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>
<!--  Update Task -->

<form action="./updateSettings.php" method="post">

<p style ="text-align:center"> 
 First Name: <input type="text" name="fName" id="fName" />
 Last Name: <input type="text" name="lName" id="lName" /><br>
 Email: <input type="text" name="uEmail" id="uEmail" /><br>
 State: <input type="text" name="uState" id="uState" />
 Phone Number : <input type="text" name="uPhone" id="uPhone" />
 Password : <input type="password" name="uPassword" id="uPassword" />

<br/><br/>
 <label for="which">Field:</label>
    <select id="which" name="which">
      <option value="fName">First Name</option>
      <option value="lName">Last Name</option>
      <option value="uEmail">Email</option>
	  <option value="uState">State</option>
	  <option value="uPhone">Phone Number</option>
	  <option value="uPassword">Password</option>
	  </select>
 <input type="submit" name="Submit" id="submit" value="Update Profile">
</p>		
		

<!-- FINISHED ADDING Task -->


<?php
$query = "select * from users where uName = '$_SESSION[un]';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Username</th>
                <th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
                <th>State</th>
				<th>Phone</th>
				<th>Role</th>
				<th>Manager</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['uName']."</td> <td>". $row['fName'] ."</td> <td>". $row['lName'] ."</td> <td>" . $row['uEmail'] . "</td> <td>" . $row['uState'] ."</td> <td>" . $row['uPhone'] ."</td><td>" . $row['uRole'] ."</td><td>" . $row['uMan'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
