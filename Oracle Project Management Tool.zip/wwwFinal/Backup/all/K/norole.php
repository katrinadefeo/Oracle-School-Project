<?php
//This is to check if the user is logged in
if(!ISSET($_SESSION["role"]))
header('Location:./InvalidCredentials.php');

?>
