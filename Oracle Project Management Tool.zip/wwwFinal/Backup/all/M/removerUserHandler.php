<html>
<body>
<?php
Session_start();

$user = $_POST['user'];
$query = "delete from users where uName = '$user';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result4 = mysqli_query($connect, $query);



mysqli_close($connect);

header('location:./removeUser.php');
	?>
	</body>
	</html>