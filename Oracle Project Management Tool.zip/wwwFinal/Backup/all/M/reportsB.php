<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Reports B</title>
  </head>
  <style>
  table {
  font-family: arial, sans-serif;
  font-size: 1.25em;
  border-collapse: collapse;
  width: 100%;
}

 

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

 

tr:nth-child(even) {
  background-color: #dddddd;
}
  
  </style>
  
  <body>
<?php
include "OracleIncludeNavbar.php" ;
include "manadmin.php";
?>

 

<h1>
<p style = "text-align: center">
Task Percentage Completion
</p>
</h1>

 


<?php
$query = "SELECT * FROM tasks ORDER BY tPercentage;";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

 

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

 

echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Task Name</th>
                <th>Task Due</th>
                <th>Percent Complete</th>
                <th>Task Owner</th>
                <th>Task Priority</th>
                <th>Task Duration</th>
                <th>Task Project</th>

 


                
                
            </tr>
            ';
            while($row = mysqli_fetch_array($result)) 
            {
            echo '<tr>';
            echo"
                <td>".$row['tName']."</td> <td>". $row['tDue'] ."</td>";
                $temp =$row['tPercentage'];
                if($temp < 33)
                echo"                
                <td style=\"background-color:#ff291e\">". $row['tPercentage'] ."</td>";
                else if($temp < 67)
                {
                    echo "<td style=\"background-color:orange\">". $row['tPercentage'] ."</td>";
                }
                                else if($temp < 100)
                {
                    echo "<td style=\"background-color:yellow\">". $row['tPercentage'] ."</td>";
                }
                                else if($temp == 100)
                {
                    echo "<td style=\"background-color:#50c878\">". $row['tPercentage'] ."</td>";
                }
                else
                {
                    echo"
                <td>". $row['tPercentage'] ."</td>";
                }
echo"                <td>" . $row['uName'] . "</td> <td>" . $row['tPriority'] ."</td> <td>" . $row['tDuration'] ."</td><td>" . $row['pName'] ."</td>" ;
                
                    echo '</tr>';
            }
            echo '</table>';
        mysqli_close($connect);
    ?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

 

  </body>
</html>
 