<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
 </head>
  
  
  <body>


   
    <div class="sidebar">
   
	
	<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;User</p>
  <a href="OracleUserHome.php">Home</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Settings</a>
 <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>
</div>
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>

<form action="./searchUserHandler.php" method="post">
<h3 style ="text-align:center">Search User</h3>
<p style ="text-align:center"> 

 Username: <input type="text" name="uName" id="uName" />
 First Name: <input type="text" name="fName" id="fName" />
 Last Name: <input type="text" name="lName" id="lName" /><br>
 Email: <input type="text" name="uEmail" id="uEmail" /><br>

 <label for="which">Field:</label>
    <select id="which" name="which">
	  <option value="uName">Username</option>
      <option value="fName">First Name</option>
      <option value="lName">Last Name</option>
      <option value="uEmail">Email</option>
	  </select><br>
 <input type="submit" name="Submit" id="submit" value="Search User">




  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
