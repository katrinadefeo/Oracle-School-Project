<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
  </head>
  
  
  <body>

   
    <div class="sidebar">
   
	
	<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;User</p>
  <a href="OracleUserHome.php">Home</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Settings</a>
 <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>
</div>
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>



<?php
$uName = $_POST['uName'];
$fName = $_POST['fName'];
$lName = $_POST['lName'];
$uEmail = $_POST['uEmail'];
$which = $_POST['which'];
switch ($which) {
    case "fName":
        $temp = $fName;
        break;
    case "lName":
        $temp = $lName;
        break;
    case "uEmail":
       $temp = $uEmail;
        break;
	case "uName":
        $temp = $uName;
        break;
	default:
	echo 'I broke';
  }
  
$query1 = "select * from users where $which like '$temp%';";
$query2 = "select * from tasks as t inner join users as u on t.uname = u.uname where u.$which like '$temp%';";
$query3 = "select * from project as p inner join users as u on p.uname = u.uname where u.$which like '$temp%';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result1 = mysqli_query($connect, $query1);
$result2 = mysqli_query($connect, $query2);
$result3 = mysqli_query($connect, $query3);

//Start User Table
echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Username</th>
                <th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
                <th>State</th>
				<th>Phone number</th>
				<th>Role</th>
				<th>Manager</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result1)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['uName']."</td> <td>". $row['fName'] ."</td> <td>". $row['lName'] ."</td> <td>" . $row['uEmail'] . "</td> <td>" . $row['uState'] ."</td> <td>" . $row['uPhone'] ."</td><td>" . $row['uRole'] ."</td><td>" . $row['uMan'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
//End user table
//Start Task table
echo'<br>
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Task Name</th>
                <th>Task Due</th>
				<th>Percent Complete</th>
				<th>Task Owner</th>
                <th>Task Priority</th>
				<th>Task Duration</th>
				<th>Task Project</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result2)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['tName']."</td> <td>". $row['tDue'] ."</td> <td>". $row['tPercentage'] ."</td> <td>" . $row['uName'] . "</td> <td>" . $row['tPriority'] ."</td> <td>" . $row['tDuration'] ."</td><td>" . $row['pName'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
//End Task Table
//Start Project Table
echo'<br>
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Project Name</th>
                <th>Project Due</th>
				<th>Project Owner</th>
                <th>Priority</th>
				<th>Budget</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result3)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['pName']."</td>"."<td>". $row['pDue'] ."</td> <td>" . $row['uName'] . "</td> <td>" . $row['pPriority'] ."</td> <td>" . $row['pBudget'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
//End Project Table

echo '<br><p  style="text-align:center"><a href="./searchUser.php">Search Again</a></p>';
		mysqli_close($connect);
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
