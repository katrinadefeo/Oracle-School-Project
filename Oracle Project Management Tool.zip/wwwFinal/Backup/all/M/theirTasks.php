<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
  </head>
  
  
  <body>

   
    <div class="sidebar">
   
	
	<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;User</p>
  <a href="OracleUserHome.php">Home</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Settings</a>
 <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>
</div>
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>
<!--  Update Task -->

<form action="./updateTask.php" method="post">

<p style ="text-align:center"> 
 <label for="tName">Task Name:</label>
<select id="tName" name="tName">
<?php
$u = $_POST['user'];
$query1 ="select tName from tasks where uName = '$u';";
$connect1 = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result1 = mysqli_query($connect1, $query1);

while($row1 = mysqli_fetch_array($result1)) 
			{
				$temp1 = $row1['0'];	
				echo '<option value='.$temp1.'>'.$temp1.'</option> ';
			}

	
	mysqli_close($connect1);
	?>
	      </select>
 Task Due: <input type="date" name="tDue" id="tDue" />
 Percent Complete: <input type="text" name="tPercentage" id="tPercentage" />
 Task Owner Username: <input type="text" name="tOwn" id="tOwn" /><br>
 <label for="tPriority">Task Priority:</label>
    <select id="pPriority" name="tPriority">
      <option value="High">High</option>
      <option value="Medium">Medium</option>
      <option value="Low">Low</option>
	      </select>
 Task Duration : <input type="text" name="tDuration" id="tDuration" />
 Task Project : <input type="text" name="tProj" id="tProj" />

<br/><br/>
 <label for="which">Field:</label>
    <select id="which" name="which">
      <option value="tDue">Task Due</option>
      <option value="tPercentage">Percent Complete</option>
      <option value="uName">Task Owner</option>
	  <option value="tPriority">Task Priority</option>
	  <option value="tDuration">Task Duration</option>
	  <option value="tProj">Task Project</option>
	  </select>
 <input type="submit" name="Submit" id="submit" value="Update Task">
</p>		
		

<!-- FINISHED ADDING Task -->


<?php
$user = $_POST['user'];
$query = "select * from tasks where uName = '$user';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Task Name</th>
                <th>Task Due</th>
				<th>Percent Complete</th>
				<th>Task Owner</th>
                <th>Task Priority</th>
				<th>Task Duration</th>
				<th>Task Project</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['tName']."</td> <td>". $row['tDue'] ."</td> <td>". $row['tPercentage'] ."</td> <td>" . $row['uName'] . "</td> <td>" . $row['tPriority'] ."</td> <td>" . $row['tDuration'] ."</td><td>" . $row['pName'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
