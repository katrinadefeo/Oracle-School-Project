<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>updateTask</title>
  </head>
  
  
  <body>
  <?php
  
  //variables
  $which = $_POST['which'];
  $uName = $_SESSION['un'];
  $fName = $_POST['fName'];
  $lName = $_POST['lName'];
  $uEmail = $_POST['uEmail'];
  $uState = $_POST['uState'];
  $uPhone = $_POST['uPhone'];
  $uPassword = $_POST['uPassword'];
  $query = "select * from users where uName = '$uName';";
  switch ($which) {
    case "fName":
        $temp = $fName;
        break;
    case "lName":
        $temp = $lName;
        break;
    case "uEmail":
       $temp = $uEmail;
        break;
	case "uState":
        $temp = $uState;
        break;
    case "uPhone":
        $temp = $uPhone;
        break;
    case "uPassword":
       $temp = $uPassword;
        break;
	default:
	echo 'I broke';
  }
  $query1 = "update users set $which = '$temp' where uName = '$uName';";
  
	//connection
	$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
if (mysqli_query($connect, $query1)) {
mysqli_close($connect);
  header('Location:./mySettings.php');
} else {
  echo "Error updating record: " . mysqli_error($connect);
}

  ?>
  </body>
</html>
