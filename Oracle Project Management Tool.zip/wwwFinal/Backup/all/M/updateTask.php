<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>updateTask</title>
  </head>
  
  
  <body>
  <?php
  
  //variables
  $which = $_POST['which'];
  $tName = $_POST['tName'];
  $tDue = $_POST['tDue'];
  $tPercentage = $_POST['tPercentage'];
  $tOwn = $_POST['tOwn'];
  $tPrior = $_POST['tPriority'];
  $tDur = $_POST['tDuration'];
  $tProj = $_POST['tProj'];
  $query = "select * from tasks where tName = '$tName';";
  switch ($which) {
    case "tDue":
        $temp = $tDue;
        break;
    case "tPercentage":
        $temp = $tPercentage;
        break;
    case "uName":
       $temp = $tOwn;
        break;
	case "tPriority":
        $temp = $tPrior;
        break;
    case "tDuration":
        $temp = $tDur;
        break;
    case "tProj":
       $temp = $tProj;
        break;
	default:
	echo 'I broke';
  }
  $query1 = "update tasks set $which = '$temp' where tName = '$tName';";
  
	//connection
	$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
if (mysqli_query($connect, $query1)) {
mysqli_close($connect);
  header('Location:./OracleHome.php');
} else {
  echo "Error updating record: " . mysqli_error($connect);
}

  ?>
  </body>
</html>
