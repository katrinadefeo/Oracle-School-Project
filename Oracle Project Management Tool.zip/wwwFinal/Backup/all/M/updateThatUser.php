<?php
// Start the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
	<style>
	.hiddenBox{
		display:none
	}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

 

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

 

tr:nth-child(even) {
  background-color: #dddddd;
}

	</style>
    <title>Oracle Update User</title>
  </head>
  
  
  <body>

   
<?php

include './OracleIncludeNavbar.php'; ?>



<form action="./updateTheirSettings.php" method="post">

<p style ="text-align:center"> 
<?php
$who = $_POST['user'];
echo'
<input type="text" class="hiddenBox" name="uName" id="uName" value="'.$who.'"  />'; ?>
 First Name: <input type="text" name="fName" id="fName" />
 Last Name: <input type="text" name="lName" id="lName" /><br>
 Email: <input type="text" name="uEmail" id="uEmail" /><br>
 State: <input type="text" name="uState" id="uState" />
 Phone Number : <input type="text" name="uPhone" id="uPhone" />
   <label for="uRole">Role:</label>
    <select id="uRole" name="uRole">
      <option value="admin">Admin</option>
      <option value="manager">Manager</option>
      <option value="user">User</option>
	</select>
 Manager: <input type="text" name="uMan" id="uMan" />
 Password : <input type="password" name="uPassword" id="uPassword" />

<br/><br/>
 <label for="which">Field:</label>
    <select id="which" name="which">
      <option value="fName">First Name</option>
      <option value="lName">Last Name</option>
      <option value="uEmail">Email</option>
	  <option value="uState">State</option>
	  <option value="uPhone">Phone Number</option>
	  <option value="uRole">Role</option>
	  <option value="uMan">Manager</option>
	  <option value="uPassword">Password</option>
	  </select>
 <input type="submit" name="Submit" id="submit" value="Update User">
</p>	
		



<?php
$user = $_POST['user'];
$query = "select * from users where uName = '$user';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Username</th>
                <th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
                <th>State</th>
				<th>Phone number</th>
				<th>Role</th>
				<th>Manager</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['uName']."</td> <td>". $row['fName'] ."</td> <td>". $row['lName'] ."</td> <td>" . $row['uEmail'] . "</td> <td>" . $row['uState'] ."</td> <td>" . $row['uPhone'] ."</td><td>" . $row['uRole'] ."</td><td>" . $row['uMan'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
