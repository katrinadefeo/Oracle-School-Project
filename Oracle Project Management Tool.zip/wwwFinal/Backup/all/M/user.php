<?php
//This is to check if the user is a user
if($_SESSION["role"]!="user")
header('Location:./InvalidCredentials.php');

?>
