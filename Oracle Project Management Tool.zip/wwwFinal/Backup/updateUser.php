<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
  </head>
    <style>
  input[type=submit] {
  font-size: 1.25em;
  width: 50%;
  margin-left: 40%;
  background-color: #F00909;
  text-align: center;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

 

input[type=submit]:hover {
  background-color: #B90909;
  text-align: center;
}</style>
  
  
  <body>


  
   
   <div class="sidebar">
div class="sidebar">
     <<br><br><br><br>
  <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
  <a href="NewOracleManagerHome.php">Home</a>
  <a href="OracleManagerResource.php">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="OracleManagerOperations.php">Operations</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div> 
	
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 

	
	<h3 style="text-align:center"> Select a user to update. </h3>
	<form action="./updateThatUser.php" method="post">

<p style ="text-align:center"> 
 <label for="tPriority">Username:</label>
    <select id="user" name="user">
<?php
$query1 ="select uName from users;";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result1 = mysqli_query($connect, $query1);

while($row1 = mysqli_fetch_array($result1)) 
			{
				$temp1 = $row1['0'];	
				echo '<option value='.$temp1.'>'.$temp1.'</option> ';
			}

	
	mysqli_close($connect);
	?>
	      </select>

<br/><br/>

 <input type="submit" name="Submit" id="submit" value="Select User">
</p>		
	    </div>7
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
