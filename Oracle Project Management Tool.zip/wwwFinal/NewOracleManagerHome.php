<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Manager Home</title>
  </head>
  <style>
  a:link {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: blue;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: white;
  background-color: transparent;
  text-decoration: underline;
}

input[type=submit] {​​​​
font-size: 1.25em;
width: 50%;
margin-left: 40%;
background-color: #F00909;
text-align: center;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
}​​​​



input[type=submit]:hover {​​​​
background-color: #B90909;
text-align: center;
}​​​​
  </style>
  
  
  <body>
 
 <!--Change to include manager.php-->

<?php
 include 'manager.php';
?> 
  
   
 <!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?> 
 
<?php

$query = "select count(*) from tasks where uName = '$_SESSION[un]';";
$query1 ="select uName from users where uMan = '$_SESSION[un]';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

while($row = mysqli_fetch_array($result)) 
			{
				$temp = $row['count(*)'];	
			}
echo'

    <div class="content">
      <div class="card">
        <div class="container">
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" style="width:10%;height:75%;margin-left:-9%;">
            &nbsp;&nbsp;<h1><b style ="color:white">'.$_SESSION["un"].'</b></h1><p><a href="./myTasks.php"><h2 style="margin-left: 31%;">you have '. $temp .' tasks.</h2></a></p>
          </p>
        </div>
		
	</div>
	

';
	
	
	mysqli_close($connect);
	?>
	
	
	
	<h3 style="text-align:center"> Select a team member to view their tasks. </h3>
	<form action="./theirTasks.php" method="post">

<p style ="text-align:center"> 
 <label for="tPriority">Username:</label>
    <select id="user" name="user">
<?php
$query1 ="select uName from users where uMan = '$_SESSION[un]';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result1 = mysqli_query($connect, $query1);

while($row1 = mysqli_fetch_array($result1)) 
			{
				$temp1 = $row1['0'];	
				echo '<option value='.$temp1.'>'.$temp1.'</option> ';
			}

	
	mysqli_close($connect);
	?>
	      </select>

<br/><br/>

 <input type="submit" name="Submit" id="submit" value="Select User">
</p>		
	    </div>7
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
