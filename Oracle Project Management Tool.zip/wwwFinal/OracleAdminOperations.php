<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
 
 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Operations</title>
  </head>
  
  <style>
  a:link {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: blue;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: white;
  background-color: transparent;
  text-decoration: underline;
}
.logout-button{
  width: 85px;
  height: 35px;
  font-size: 1.05em;
}
  </style>
  <body>
   
<?php 
include 'manadmin.php';
?>
   

<?php
include "OracleIncludeNavbar.php";
?>

    <div class="content">
      <div class="card">

		 <!--Container for Adding Tasks-->

      <div class="container">
      <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
            &nbsp;&nbsp;<a href="OracleAdminProjects.php"><div class="container">
          <h3><b style="text-align: center">View Projects </b></h3>
          <p>
            <br><br></a> 
          </p>
        </div>
      </div>

      <!--Container for Adding Projects-->
      <div class="container">
      <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
            &nbsp;&nbsp;<a href="OracleAdminTasks.php"><div class="container">
          <h3><b style="text-align: center">View Tasks </b></h3>
          <p>
            <br><br></a> 
          </p>
        </div>
      </div>

		 <!--Container for Remove Project-->

         <div class="container">
      <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
            &nbsp;&nbsp;<a href="OracleAdminRemoveProject.php"><div class="container">
          <h3><b style="text-align: center"> Remove Projects </b></h3>
          <p>
            <br><br></a> 
          </p>
        </div>
      </div>
		
		 <!--Container for Remove Tasks-->
		 <div class="container">
			<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
            &nbsp;&nbsp;<a href="OracleAdminRemoveTask.php"><div class="container">
          <h3><b style="text-align: center">Remove Tasks</b></h3>
          <p>
            <br><br></a> 
          </p>
        </div>
      </div>
      
        </div>
	
  <!--Footer-->
<div class="footer">
  <h4>&copy UCCS Oracle Team 1</h4>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
