<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>

 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Projects</title>
	
 <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}input[type=submit] {​​
font-size: 1.25em;
width: 50%;
margin-left: 40%;
background-color: #F00909;
text-align: center;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
}​​



input[type=submit]:hover {​​
background-color: #B90909;
text-align: center;
}​​
 </style>
  
  </head>
  <body>
   
<?php 
include 'manadmin.php';
?>
   	
<!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?> 

<!--  ADDING PROJECT -->

<form action="./addProject.php" method="post">

<p style ="text-align:center"> 
 Project Name: <input type="text" name="pName" id="pName" />
 Project Due: <input type="date" name="pDue" id="pDue" />
 Project Owner Username: <input type="text" name="pOwn" id="pOwn" />
 <label for="pPriority">Priority:</label>
    <select id="pPriority" name="pPriority">
      <option value="High">High</option>
      <option value="Medium">Medium</option>
      <option value="Low">Low</option>
	      </select>
 Project Budget: <input type="text" name="pBudget" id="pBudget" />

<br/><br/>

 <input type="submit" name="Submit" id="submit">
</p>		
		

<!-- FINISHED ADDING PROJECT -->

<?php

$query = "select * from project;";

//connection
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect,$query);


echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Project Name</th>
                <th>Project Due</th>
				<th>Project Owner</th>
                <th>Priority</th>
				<th>Budget</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['pName']."</td>"."<td>". $row['pDue'] ."</td> <td>" . $row['uName'] . "</td> <td>" . $row['pPriority'] ."</td> <td>" . $row['pBudget'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
		?>
	
<br><br><br><br><br><br><br><br><br><br><br><br>		
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>