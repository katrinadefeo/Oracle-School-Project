<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>


    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />

	
    <title>Oracle Remove Tasks</title>
<style>	
input[type=text], select {
  background-color: #D4D4D4;
  font-size: 1.25em;
  width: 50%;
  margin-left: 40%;
  padding: 12px 20px;
  text-align: center;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  clear: both;
}

#tName, #tOwn{​​

width: 50%;
margin-left: 25%;
clear: both;
}​​

.container2 input {
  width: 100%;
  clear: both;
}

input[type=submit] {
  font-size: 1.25em;
  width: 50%;
  margin-left: 40%;
  background-color: #F00909;
  text-align: center;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #B90909;
  text-align: center;
}

div {
  
  border-radius: 5px;
  background-color: #white;
  padding: 20px;
  
  
}

table {
  font-family: arial, sans-serif;
  font-size: 1.25em;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<body>

<?php 
include 'manadmin.php';
?>
   

<!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?> 

<div class="container2">

 <form action="OracleDeleteTaskHandler.php" method= "post" align="center">
	<p style="center">
	<h3>
	Remove Task
	</h3>
    </p>
	<p>
	<h4>
	If you are deleting multiple, only the Task Owner is required. Please ensure you have the correct spelling.
	</h4>
	</p>
    <label for="tName">Task Deletion</label>
    <input type="text" id="tName" name="tName" placeholder="Task Name">
    <input type="text" id="tOwn" name="tOwn" placeholder="Task Owner">
    <input type="submit" name="del" value="Delete">
    <input type="submit" name="del" value="Delete Multiple">
  </form>
</div>
<br>	

<?php

$query = "select * from tasks;";

//connection
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect,$query);


echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Task Name</th>
                <th>Task Due</th>
				<th>Task Percentage</th>
                <th>Priority</th>
				<th>Task Owner</th>
				<th>Task Duration</th>
				<th>Task Project</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['tName']."</td>"."<td>". $row['tDue'] ."</td> <td>" . $row['tPercentage'] . "</td> <td>" . $row['tPriority'] ."</td> <td>" . $row['uName'] ."</td> <td>" . $row['tDuration'] ."</td> <td>" . $row['pName'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
		?>
<br><br><br><br><br><br><br><br>		

<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
</body>
</html>
