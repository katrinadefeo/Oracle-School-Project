<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
 <head>

 
  
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Resource</title>
	
 <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
 </style>
    
  </head>
  <body>
   
<?php 
include 'manadmin.php';
?>
   
   
<!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?>  
<h1>
<p style = "text-align: center">
Resource
</p>
</h1>
<?php

$query = "select uName, count(*) from tasks group by uName;";

//connection
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect,$query);


echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Username</th>
                <th>% Utilization</th>	
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
				$temp = $row['count(*)'] * 12;		
            echo '<tr>';
			echo"
                <td>".$row['uName']."</td>";
				if($temp > 100)
				{
					echo "<td style=\"background-color:red\">". $temp ."</td>";
				}
				else
					echo "<td>". $temp ."</td>";
			echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
		?>
	
<br><br><br><br><br><br><br><br><br><br><br><br>		
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>