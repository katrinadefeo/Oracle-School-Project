<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  
    <style>
     a:link {​​
color: white;
background-color: transparent;
text-decoration: none;
}​​
a:visited {​​
color: white;
background-color: transparent;
text-decoration: none;
}​​
a:hover {​​
color: blue;
background-color: transparent;
text-decoration: underline;
}​​
a:active {​​
color: white;
background-color: transparent;
text-decoration: underline;
}​​
.logout-button{​​
width: 85px;
height: 35px;
font-size: 1.05em;
}​​
    </style>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
	
    <title>User Management</title>

  </head>
  <body>
  
 <?php 
include 'admin.php';
?>
   
<!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?> 


<div class="content">
<div class="card">





<!--Container for Adding Tasks-->





<div class="container">
<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
&nbsp;&nbsp;<a href="./addUser.php"><div class="container">
<h3><b style="text-align: center;color:white">Add User </b></h3>
<p>
<br><br></a>
</p>
</div>
</div>





<!--Container for Adding Projects-->
<div class="container">
<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
&nbsp;&nbsp;<a href="./updateUser.php"><div class="container">
<h3><b style="text-align: center;color:white">Update User </b></h3>
<p>
<br><br></a>
</p>
</div>
</div>





<!--Container for Remove Project-->





<div class="container">
<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
&nbsp;&nbsp;<a href="./removeUser.php"><div class="container">
<h3><b style="text-align: center;color:white"> Remove User </b></h3>
<p>
<br><br></a>
</p>
</div>
</div>

<div class="container">
<img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:250px;height:50px;">
&nbsp;&nbsp;<a href="./searchUser.php"><div class="container">
<h3><b style="text-align: center;color:white"> Search User </b></h3>
<p>
<br><br></a>
</p>
</div>
</div>

<!--Container for Remove Tasks-->


</div>
<!--
    <div class="content">
      <div class="card">
        <a href="./addUser.php">
          <div class="container">
            <h4>ADD USER</h4>
  
          </div>
        </a>

        <a href="./updateUser.php">
          <div class="container">
            <h4>UPDATE USER</h4>
        
          </div>
        </a>
      </div>


      <div class="card">
          <a href="./removeUser.php">  
            <div class="container">
              <h4><b>REMOVE USER</b></h4>
               
            </div>
          </a>  

          <a href="./searchUser.php">
              <div class="container">
                <h4><b>SEARCH USER</b></h4>    
              </div>
          </a>
    </div>
	-->
<br><br><br><br><br><br><br><br><br><br><br><br>			
<!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
