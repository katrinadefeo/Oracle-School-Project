<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
	
		
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Home</title>
  </head>
  
  <body>
 
 <?php
	include './header.php';
?>
   
   <div class="sidebar">
      <<br><br><br><br>
  <a href="Coming_Soon.html">Home</a>
  <a href="Coming_Soon.html">Resource</a>
  <a href="Coming_Soon.html">Guide</a>
  <a href="Coming_Soon.html">Reports</a>
  <a href="Coming_Soon.html">Operations</a>
  <a href="Coming_Soon.html">User Management</a>
  <a href="Coming_Soon.html">Settings</a>
  <a href="OracleLogOut.php"><button class="logout-button">Logout</button></a>
    </div>
	
	
<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left:250px;width:300px;height:200px;"><br>
 
</div>

    <div class="content">
      <div class="card">
        <div class="container">
          <h4><b>John Doe</b></h4>
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum,
            expedita?
          </p>
        </div>
        <div class="container">
          <h4><b>John Doe</b></h4>
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum,
            expedita?
          </p>
        </div>
      </div>
      <div class="card">
        <div class="container">
          <h4><b>John Doe</b></h4>
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum,
            expedita?
          </p>
        </div>
        <div class="container">
          <h4><b>John Doe</b></h4>
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png" align= "left" style="width:200px;height:50px;">
            &nbsp;&nbsp;Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum,
            expedita?
          </p>
        </div>
		
      </div>
	  
    </div>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
