

<!DOCTYPE html>
<html lang="en">
 <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
 </head>
    
<body>
<?php


	//User Nav Bar
	if($_SESSION["role"] == "user") {
		
		echo '<div class="sidebar">
        <br><br><br><br><br><br>
        <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;User</p>
        <a href="OracleUserHome.php">Home</a>
        <a href="Coming_Soon.html">Guide</a>
        <a href="./mySettings.php">Settings</a>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<a href="OracleLogOut.php">Logout</a>
        </div>';
    }
	//Manager Nav Bar
	elseif($_SESSION["role"] == "manager") {
		
		echo '<div class="sidebar">
       <br><br><br><br><br><br>
       <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Manager</p>
       <a href="NewOracleManagerHome.php">Home</a>
       <a href="OracleAdminResource.php">Resource</a>
       <a href="Coming_Soon.html">Guide</a>
       <a href="reports.php">Reports</a>
       <a href="OracleAdminOperations.php">Operations</a>
       <a href="./mySettings.php">Settings</a>
       <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	   <a href="OracleLogOut.php">Logout</a>
		</div>';
	}
		
	else {
		
		echo '<div class="sidebar">
      <<br><br><br><br><br><br>
      <p style=color:white;font-family:Arial;font-size:20px;>&nbsp;&nbsp;&nbsp;Administrator</p>
      <a href="OracleAdminHome.php">Home</a>
      <a href="OracleAdminResource.php">Resource</a>
      <a href="Coming_Soon.html">Guide</a>
      <a href="reports.php">Reports</a>
      <a href="OracleAdminOperations.php">Operations</a>
      //Double check file name for User Management
	  <a href="OracleAdminUserManagement.php">User Management</a>
      <a href="mySettings.php">Settings</a>
	  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
      <a href="OracleLogOut.php">Logout</a>
	  </div>';
		
	}
				
	
	
?>


<!--Oracle Banner-->
<div class="main">
 
 <img src="https://logos-world.net/wp-content/uploads/2020/09/Oracle-Logo.png" style="margin-left: 43%; margin-bottom: -3%; width:300px;height:200px;"><br>
 
</div>


</body>
</html>


