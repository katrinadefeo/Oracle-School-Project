<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle User Home</title>
  </head>
  <style>
  a:link {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: blue;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: white;
  background-color: transparent;
  text-decoration: underline;
}
  </style>
  
  <body>
 <?php
//This is to check if the user is a user
if($_SESSION["role"]!="user")
header('Location:./InvalidCredentials.php');

?>

   
<!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?> 


<?php

$query = "select count(*) from tasks where uName = '$_SESSION[un]';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

while($row = mysqli_fetch_array($result)) 
			{
				$temp = $row['count(*)'];	
			}
echo'

    <div class="content">
      <div class="card">
        <div class="container">
          <p>
            <img src="https://cdn.freebiesupply.com/logos/large/2x/oracle-6-logo-black-and-white.png"   style="width:10%;height:40%;margin-left:-9%;">
            <br><br><br><h1><b style ="color:white">'.$_SESSION["un"].'</b></h1><p><br> <a href="./myTasks.php"> <h2 style= "margin-left: 35%;">you have '. $temp .' tasks. </h2></a></p>
          </p>
        </div>
	</div>
	  
    </div>';
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
