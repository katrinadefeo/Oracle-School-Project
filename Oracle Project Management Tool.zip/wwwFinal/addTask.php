<?php
session_start();
?>



<?php
//variables
$tName = $_POST['tName'];
$tDue = $_POST['tDue'];
$tOwn = $_POST['tOwn'];
$tPriority = $_POST['tPriority'];
$tDuration = $_POST['tDuration'];
$tProj = $_POST['tProj'];

//connection

$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//queries
$query = " insert into tasks (tName, tDue, tPriority, uName, tDuration, pName) values ('$tName', STR_TO_DATE('$tDue','%Y-%m-%d'), '$tPriority', '$tOwn','$tDuration', '$tProj'); ";

echo "$query";

$result = mysqli_query($connect, $query);

mysqli_close($connect);


header('Location:./OracleAdminTasks.php');

?>
