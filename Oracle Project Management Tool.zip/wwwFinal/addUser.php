<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Add User</title>
 </head>
  <style>
  input[type=submit] {
  font-size: 1.25em;
  width: 50%;
  margin-left: 40%;
  background-color: #F00909;
  text-align: center;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

 

input[type=submit]:hover {
  background-color: #B90909;
  text-align: center;
}</style>
  
  <body>


   
<?php include './OracleIncludeNavBar.php'; ?>
<!--  Update Task -->

<form action="./addUserHandler.php" method="post">

<p style ="text-align:center"> 
 Username: <input type="text" name="uName" id="uName" />
 First Name: <input type="text" name="fName" id="fName" />
 Last Name: <input type="text" name="lName" id="lName" /><br>
 Email: <input type="text" name="uEmail" id="uEmail" /><br>
 State: <input type="text" name="uState" id="uState" />
 Phone Number : <input type="text" name="uPhone" id="uPhone" />
  <label for="uRole">Role:</label>
    <select id="uRole" name="uRole">
      <option value="admin">Admin</option>
      <option value="manager">Manager</option>
      <option value="user">User</option>
	</select>
 Password : <input type="password" name="uPassword" id="uPassword" />
 Manager : <input type="text" name="uMan" id="uMan" /><br>
 <input type="submit" name="Submit" id="submit" value="Add User">
<!-- FINISHED ADDING Task -->



  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
