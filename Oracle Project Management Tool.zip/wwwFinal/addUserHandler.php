<html>
<body>
<?php

session_start();


//variables

$uName = $_POST['uName'];
$fName = $_POST['fName'];
$lName = $_POST['lName'];
$uEmail = $_POST['uEmail'];
$uState = $_POST['uState'];
$uPhone = $_POST['uPhone'];
$uRole = $_POST['uRole'];
$uPassword = $_POST['uPassword'];
$uMan = $_POST['uMan'];

$query = " insert into Users (uName, fName, lName, uEmail, uState, uPhone, uRole, uPassword, uMan) values ('$uName', '$fName', '$lName', '$uEmail', '$uState', $uPhone, '$uRole', '$uPassword', '$uMan'); ";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);
mysqli_close($connect);

header('Location:./addUser.php');
	?>
	</body>
	</html>