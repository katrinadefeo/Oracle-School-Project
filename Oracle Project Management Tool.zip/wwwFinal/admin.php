<?php
//This is to check if the user is an admin
if($_SESSION["role"]!="admin")
header('Location:./InvalidCredentials.php');

?>
