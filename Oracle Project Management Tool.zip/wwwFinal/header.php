
<?php


switch ($_SESSION["role"])
{
case "admin":
print($_SESSION["role"]);
header('Location:./OracleAdminHome.php');
break;
case "manager":
print($_SESSION["role"]);
header('Location:./NewOracleManagerHome.php');
break;
case "user":
print($_SESSION["role"]);
header('Location:./OracleUserHome.php');
break;
default:
print($_SESSION["role"]);
header('Location:./invalidCredentials.php');
}
?>