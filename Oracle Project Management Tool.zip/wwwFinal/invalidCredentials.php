<?php
Session_start();
Session_unset();
Session_destroy();
?>
<html>
<head>
<title>Invalid Credentials</title>
	<link rel = "stylesheet" type = "text/css" href="./css/OracleLoginStyle.css">
<style>
a:link {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: blue;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: white;
  background-color: transparent;
  text-decoration: underline;
}
</style>

<body>
   <div style="text-align:center; color:white"><br><br><br><br><h3>You have reached the previous page in error and have been logged out for secuirty concerns.</h3><br><h3>Please relogin to continue</h3></div>
<div class="loginbox">
	<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAAA+VBMVEX7JSX////6Hh77TU38IiL7GRn8///7T0/8GBfv///8Hh30///9IiH8FRTs///9gID+DQvwg4b3goP8DQz0YmT49PXmICf4RkbUcH7afonqhozoiZDfJC3xQkXlqrLl5Oz2cnXsGR7YXmrqRErTl6XUi5n+AgHwtrn6rKzO1+fkw8zgt8HvZ2neiJLsOD348PHgkpv329zhTVL5kJHyJCfnPkbcanT05ejjfobylJfrc3bvNDfT7PXq8fbRpK/Kq7n5XV3hFBrFvdDdvMTZ1ODXJzP5NDTGboDDfZDY///pl5zo1t3oWV353t74X1/6x8f8z9C+//+nXHOCvEbmAAAD/ElEQVR4nO3bbVfTMBgG4CUmXdcts7Mb8jZYGY4XERwMBwN1KKCCCvr/f4zdUChuaxPpMc849/WJw+FD7tM8ydMm5HIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAj4Tg7hAv2R7JQ3DlzzyfnZtfmJt9vugrbns8/6bk+vWlZcdhQ46zvFT3pbA9KmNCzVTK7C/lRuhOWRRXjsYYKDRCaXtsJvyV2rgYA7Wmb3t0+lqrzqQckRdTk6S1lhAjst6yPUItwt9IzsHY5lQkkSnPY+DlFMwuuZWeg7FXge1xpkuq8zvbnu1xpgh2tHKwIvEycZ/q5WDstbI91iQiLOgGKYSUmxW3oZuDsQXCj0Twtn6QLuFW2NvVz8FYk+7C5e6ZBFmiO7ekwcxirE02iMgVTYKUO1SLRORMcjC2T7VI+LZZkDdUXxblM7MgT8kG0e5PEOT/eDRTi9fNgpAtdtPlt071G6rgem+HvxVyVDfEXNA1CdKl+97uzpsE2XNtj3cisyLZpdqhRPhb/RxlTrZEop2kqh+kSnXxHRBKe90qzJA+jNN/JBWyr1U3fM0VuEz966/uOwn5T6Y5taVTJgfEJ9aAOkzPcTEFOXIi/Tv2WkB4C7kjgouU5zEdOSJ+L6FOnC26zeIIdbQ8Kcfx0TTUxy2PV8Z+rCs2Fun2vGMJtdgb6SCPq9wl3ZjcEupu3pRctf+uPSiWYcE47YtzGTtJCBThipey/b4VG5+ngjDsV/vVaj88OVGxhyFaHy4l2fZX1aMdZN2913wI4Q0JEX8AUm1G/W+eaNkHvZt6PkqbNMJvDleCYoXihiJat9vgIU9amYTiS3/+8iW94zehPt6tTrXGxLtyJcXnYje5TgNiq5hQp/e3755U3kgWIf2zhfsX0k4VrSTByOnhzlpfKen9rnFRilZjN1z5OLJNbpCaXUFl3DZeazeanZAHQeCHZ+efVjfH3g58TehdUfXGjfBmjhWdWrdbc8qT28jPZJpI3jH65juS9YjIziik0SffUV9CGgWf9h6V7h2JLd4zPMsdo0jiNkdgdN1hvEsC9S6/PjwHY7P2X7d87atmSYrWH4l7kEUOxiq2H4lvcCKSpGC5U/Ga2eSwfn4VXGYVxO7CJR7WnMQ5Vm9vef2scjB2YLPclcaFfl3XFueW4d2/ZMWOvdbR7HpsmhV73bz74L43zuLpj/qWZZBla9UuVIYlEhWJtWv/3n6WOSzeMfe+ZxukaiuIu5BtkHlbRZLtomXx1r+6yjbI1WMJYu3fFx7PE7lmTlYGJ40/bH0F9qr5J8by+fgP+div8z9trVriXPCseNzr2GsaKZ1sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2/APWNR42kNxwPAAAAAElFTkSuQmCC" class="avatar">
    
	<form action="OracleLoginHandler.php" method="POST">
	<p>Username</p>
	<input type="text" name="un" placeholder="Enter Username">
	<p>Password</p>
	<input type="password" name="pw" placeholder="Enter Password"><br>
	<input type="submit" value="Submit"><br>
	<a href="OracleCreateUser.html">Click Here to Create an account</a><br>
	<a href="OracleForgotPassword.html">Forgot Password</a><br>
	</form>
	
</div>
	
</body>
</head>
</html>