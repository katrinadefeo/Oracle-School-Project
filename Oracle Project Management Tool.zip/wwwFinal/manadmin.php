<?php
//This is to check if the user is a manager or an admin
if(!isset($_SESSION["role"])) {
header('Location:./InvalidCredentials.php');
}
else if ($_SESSION["role"] == "user"){
    header('Location:./InvalidCredentials.php');
}

 


?>
