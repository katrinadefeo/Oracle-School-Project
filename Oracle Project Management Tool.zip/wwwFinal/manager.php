<?php
//This is to check if the user is a manager
if($_SESSION["role"]!="manager")
header('Location:./InvalidCredentials.php');

?>
