<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Settings</title>
 </head>
  <style>
  table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

input[type=submit] {​​
font-size: 1.25em;
width: 50%;
margin-left: 40%;
background-color: #F00909;
text-align: center;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
}​​



input[type=submit]:hover {​​
background-color: #B90909;
text-align: center;
}​​
  </style>
  
  <body>
 


<?php
//This is to check if the user logged in
include "norole.php";

?>
   
<!--Navbar and Banner--> 
<?php
 include 'OracleIncludeNavbar.php';
?> 

   
 
</div>
<!--  Update Task -->

<form action="./updateSettings.php" method="post">

<p style ="text-align:center"> 
 First Name: <input type="text" name="fName" id="fName" />
 Last Name: <input type="text" name="lName" id="lName" /><br>
 Email: <input type="text" name="uEmail" id="uEmail" /><br>
 State: <input type="text" name="uState" id="uState" />
 Phone Number : <input type="text" name="uPhone" id="uPhone" />
 Password : <input type="password" name="uPassword" id="uPassword" />

<br/><br/>
 <label for="which">Field:</label>
    <select id="which" name="which">
      <option value="fName">First Name</option>
      <option value="lName">Last Name</option>
      <option value="uEmail">Email</option>
	  <option value="uState">State</option>
	  <option value="uPhone">Phone Number</option>
	  <option value="uPassword">Password</option>
	  </select><br>
 <input type="submit" name="Submit" id="submit" value="Update Profile">
</p>		
		

<!-- FINISHED ADDING Task -->


<?php
$query = "select * from users where uName = '$_SESSION[un]';";
$connect = mysqli_connect("127.0.0.1", "Oracle", "123", "Oracle");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($connect, $query);

echo'
<table style="width:800px" border="2" align="center" bgcolor="white">
            
            <tr>
                <th>Username</th>
                <th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
                <th>State</th>
				<th>Phone</th>
				<th>Role</th>
				<th>Manager</th>

				
				
            </tr>
            ';
			while($row = mysqli_fetch_array($result)) 
			{
            echo '<tr>';
			echo"
                <td>".$row['uName']."</td> <td>". $row['fName'] ."</td> <td>". $row['lName'] ."</td> <td>" . $row['uEmail'] . "</td> <td>" . $row['uState'] ."</td> <td>" . $row['uPhone'] ."</td><td>" . $row['uRole'] ."</td><td>" . $row['uMan'] ."</td>" ;
					echo '</tr>';
			}
			echo '</table>';
		mysqli_close($connect);
	?>
  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
