<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./style2.css" />
    <title>Oracle Search User</title>
 </head>
    <style>
  input[type=submit] {
  font-size: 1.25em;
  width: 50%;
  margin-left: 40%;
  background-color: #F00909;
  text-align: center;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

 

input[type=submit]:hover {
  background-color: #B90909;
  text-align: center;
}</style>
  
  
  <body>


   
<?php
include './admin.php';
include './OracleIncludeNavBar.php';
?>
 

<form action="./searchUserHandler.php" method="post">
<h3 style ="text-align:center">Search User</h3>
<p style ="text-align:center"> 

 Username: <input type="text" name="uName" id="uName" />
 First Name: <input type="text" name="fName" id="fName" />
 Last Name: <input type="text" name="lName" id="lName" /><br>
 Email: <input type="text" name="uEmail" id="uEmail" /><br>

 <label for="which">Field:</label>
    <select id="which" name="which">
	  <option value="uName">Username</option>
      <option value="fName">First Name</option>
      <option value="lName">Last Name</option>
      <option value="uEmail">Email</option>
	  </select><br>
 <input type="submit" name="Submit" id="submit" value="Search User">




  <!--Footer-->
<div class="footer">
  <p>&copy UCCS Oracle Team 1</p>
  <p>Benard Cheserem, Katrina DeFeo, Mohammed Shaikh, Nicholas Traczek</p>
</div>

  </body>
</html>
